import numpy as np
def sin(x):
  return np.sin(x)