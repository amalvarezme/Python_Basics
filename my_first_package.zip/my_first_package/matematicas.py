def parabola(a,b,c,x):
  y=a*x**2+b*x+c
  return y